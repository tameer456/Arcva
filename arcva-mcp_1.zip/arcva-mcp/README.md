# Arcva MCP Server

AI-powered startup OS for Claude. Lets any Claude user connect their Arcva account and manage their startup directly from Claude.ai.

---

## What this does

When a Claude user connects Arcva, they can say things like:

- *"What tasks do I have in progress?"*
- *"Log a $500 expense for hosting"*
- *"Add Notion as a competitor and analyze their weaknesses"*
- *"Create an Instagram post for my product launch"*
- *"Give me strategic advice on my go-to-market"*

Claude will call the right Arcva MCP tool and take action directly inside their Arcva account.

---

## MCP Tools exposed

| Tool | What it does |
|------|-------------|
| `get_startup_context` | Read user's business profile |
| `update_business` | Update stage, goals, industry |
| `business_advisor` | Ask AI advisor, saves chat history |
| `get_business_plan` | Read existing business plans |
| `create_business_plan` | Write business plan sections |
| `manage_tasks` | List, create, update tasks |
| `track_financials` | Log transactions, get summary |
| `research_competitor` | Track and analyze competitors |
| `create_marketing_content` | Generate and save marketing content |

---

## Project structure

```
arcva-mcp/
├── index.js          ← MCP server (all 9 tools)
├── arcva-client.js   ← Base44 API wrapper
├── oauth-server.js   ← OAuth 2.0 HTTP server
├── package.json
├── .env.example      ← Copy to .env and fill in
└── README.md
```

---

## Deployment (step by step)

### 1. Clone and install

```bash
git clone https://github.com/yourname/arcva-mcp
cd arcva-mcp
npm install
```

### 2. Set environment variables

```bash
cp .env.example .env
# Fill in ANTHROPIC_API_KEY and OAUTH_CLIENT_SECRET
```

### 3. Deploy to a server

Recommended: **Railway, Render, or Fly.io** (all have free tiers)

```bash
# Railway (easiest)
npm install -g railway
railway login
railway init
railway up
```

Your server will be live at a URL like:
`https://arcva-mcp.railway.app`

### 4. Point your domain

In your domain registrar (IONOS/Namecheap), add a CNAME:
```
mcp.arcva.app → arcva-mcp.railway.app
```

Now your MCP server is at: `https://mcp.arcva.app`

### 5. Run both servers

```bash
# Terminal 1 — MCP server (stdio)
npm start

# Terminal 2 — OAuth server (HTTP)
npm run start:oauth
```

---

## Submitting to Anthropic

Go to: **https://docs.anthropic.com/en/build-with-claude/mcp/connector-directory**

You'll need to provide:

| Field | Your value |
|-------|-----------|
| Connector name | Arcva |
| Description | AI-powered startup OS — manage your business plan, tasks, financials, competitors, and marketing from Claude |
| MCP server URL | `https://mcp.arcva.app` |
| OAuth authorize URL | `https://mcp.arcva.app/oauth/authorize` |
| OAuth token URL | `https://mcp.arcva.app/oauth/token` |
| OAuth scopes | `business:read business:write tasks:read tasks:write financials:read financials:write` |
| Logo | Upload arcva_icon.png |
| Website | `https://arcva.app` |

---

## Local testing

Test the MCP server locally with the MCP Inspector:

```bash
npx @modelcontextprotocol/inspector node index.js
```

This opens a browser UI where you can call each tool manually and verify responses before submitting to Anthropic.

---

## Security notes

- All data is scoped per user via Base44 RLS rules — users can only access their own records
- OAuth tokens expire after 30 days
- Auth codes expire after 10 minutes
- In production, replace the in-memory token store with Redis

---

## Support

Built on [Base44](https://base44.com) · Powered by [Arcva](https://arcva.app)
